﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Isporttechnologiestest
{
    public partial class CategoryMaster : System.Web.UI.Page
    {
        string str = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

                showdata();
            }
        }

        protected void ClearControls()
        {
            this.txtCategory.Text = String.Empty;


        }

        protected void BtnSave_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(str))
            {

                SqlCommand cmd = new SqlCommand("sp_Insertcategory", con);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@CategoryName", txtCategory.Text.ToString());
                cmd.Parameters.AddWithValue("@IsActive", 1);
                cmd.ExecuteNonQuery();
                Label1.Text = "data Save successfully";

                ClearControls();


            }
        }

        public void showdata()
        {

            //string str = ConfigurationManager.ConnectionStrings["raj"].ConnectionString;
            using (SqlConnection con = new SqlConnection(str))
            {
                // con.Open();
                SqlCommand cmd = new SqlCommand("sp_GetCategoryDetails", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
             
                GridView1.DataSource = cmd.ExecuteReader();
                GridView1.DataBind();


            }


        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            showdata();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            showdata();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GridView1.Rows[e.RowIndex];
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
            TextBox Category_Name = (TextBox)row.Cells[0].Controls[0];

            using (SqlConnection con = new SqlConnection(str))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("sp_Updatecategory", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Category_Id", id);
                cmd.Parameters.AddWithValue("@CategoryName", Category_Name.Text.ToString());
                cmd.ExecuteNonQuery();
                Label2.Text = "Data updated successfully";
                GridView1.EditIndex = -1;
                this.showdata();
            }
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            GridViewRow row = GridView1.Rows[e.RowIndex];
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
            //TextBox Category_Name = (TextBox)row.Cells[0].Controls[0];

            using (SqlConnection con = new SqlConnection(str))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("sp_Deletecategory", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Category_Id", id);
                cmd.ExecuteNonQuery();
                Label2.Text = "Data Delete successfully";
                GridView1.EditIndex = -1;
                this.showdata();
            }
        }

    }

}
