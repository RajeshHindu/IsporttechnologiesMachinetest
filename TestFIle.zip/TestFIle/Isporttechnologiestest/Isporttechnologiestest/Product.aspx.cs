﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Isporttechnologiestest
{
    public partial class Product : System.Web.UI.Page
    {
        string str = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PopulateDropdown();
                showdata();
            }
        }

        protected void ClearControls()
        {
            this.txtProductName.Text = String.Empty;
            this.TxtPrice.Text = String.Empty;
            this.ddlCategoryName.SelectedValue = Convert.ToString(0);


        }

        protected void PopulateDropdown()
        {
            using (SqlConnection con = new SqlConnection(str))
            {
                // con.Open();
                SqlCommand cmd = new SqlCommand("sp_GetCategoryDetails", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();

                ddlCategoryName.DataSource = cmd.ExecuteReader();
                ddlCategoryName.DataTextField = "Category_Name";
                ddlCategoryName.DataValueField = "Category_Id";
                ddlCategoryName.DataBind();
                ddlCategoryName.Items.Insert(0, "Select");


            }


        }

        public void showdata()
        {
            using (SqlConnection con = new SqlConnection(str))
            {
                // con.Open();
                SqlCommand cmd = new SqlCommand("sp_GetProductDetails", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();

                GridView1.DataSource = cmd.ExecuteReader();
                GridView1.DataBind();


            }


        }


        protected void BtnSave_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(str))
            {

                SqlCommand cmd = new SqlCommand("sp_InsertProduct", con);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@Product_Name", txtProductName.Text.ToString());
                cmd.Parameters.AddWithValue("@Price", TxtPrice.Text.ToString());
                cmd.Parameters.AddWithValue("@Category_Id", ddlCategoryName.SelectedValue);
                cmd.Parameters.AddWithValue("@IsActive", 1);
                cmd.ExecuteNonQuery();
                Label1.Text = "data Save successfully";

                ClearControls();


            }

        }

        protected void btnView_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(str))
            {
                int id = Convert.ToInt16((sender as LinkButton).CommandArgument);
                
                con.Open();
                SqlDataAdapter adptr = new SqlDataAdapter("spViewData", con);
                adptr.SelectCommand.CommandType = CommandType.StoredProcedure;
                adptr.SelectCommand.Parameters.AddWithValue("@Product_Id", id);
                DataTable dt = new DataTable();
                adptr.Fill(dt);
                txtProductName.Text = dt.Rows[0]["Product_Name"].ToString();
                TxtPrice.Text = dt.Rows[0]["Price"].ToString();
                ddlCategoryName.ClearSelection();
                string selectedText = dt.Rows[0]["Category_Name"].ToString();
                ddlCategoryName.Items.FindByText(selectedText).Selected = true;
                //ddlCategoryName.SelectedItem.Text = dt.Rows[0]["Category_Name"].ToString();
                Session["Product_Id"] = id;
                
                
            }
        }

        protected void BtnUpdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(str))
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("sp_UpdateProduct", con);
                cmd.CommandType = CommandType.StoredProcedure;
                int Id = Convert.ToInt32(Session["Product_Id"]);

                cmd.Parameters.AddWithValue("@Product_Name", txtProductName.Text);
                cmd.Parameters.AddWithValue("@Price", TxtPrice.Text);
                cmd.Parameters.AddWithValue("@Category_Id", ddlCategoryName.SelectedValue);
                cmd.Parameters.AddWithValue("@Product_Id", Id);

                cmd.ExecuteNonQuery();
                showdata();
                ClearControls();
            }
        }

        protected void BtnDelete_Click(object sender, EventArgs e)
        {
          
            //TextBox Category_Name = (TextBox)row.Cells[0].Controls[0];

            using (SqlConnection con = new SqlConnection(str))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("sp_DeleteProduct", con);
                int Id = Convert.ToInt32(Session["Product_Id"]);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Product_Id", Id);
                cmd.ExecuteNonQuery();
                //Label2.Text = "Data Delete successfully";
                GridView1.EditIndex = -1;
                this.showdata();
                ClearControls();
            }
        }
    }
}